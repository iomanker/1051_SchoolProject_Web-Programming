﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' 組件的一般資訊是由下列的屬性集 
' 控制。變更這些屬性值可修改與組件關聯的
' 資訊。

' 檢閱組件屬性的值
<Assembly: AssemblyTitle("Final_Exam_Project")> 
<Assembly: AssemblyDescription("")> 
<Assembly: AssemblyCompany("")> 
<Assembly: AssemblyProduct("Final_Exam_Project")> 
<Assembly: AssemblyCopyright("Copyright (C)  2016")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)>

'如果此專案公開至 COM，則下列 GUID 就是適用於 typelib 的識別碼
<Assembly: Guid("eebf7516-5e79-4d1c-abdb-aa08436d17a0")> 

' 組件的版本資訊是由下列四項值構成:
'
'      主要版本
'      次要版本 
'      組建編號
'      修訂編號
'
' 您可以指定所有的值，也可以依照以下的方式，使用 '*' 將組建和修訂編號 
' 指定為預設值:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.0.0.0")> 
<Assembly: AssemblyFileVersion("1.0.0.0")> 
