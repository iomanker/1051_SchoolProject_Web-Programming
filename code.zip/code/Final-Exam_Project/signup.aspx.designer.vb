﻿'------------------------------------------------------------------------------
' <自動產生的>
'     這段程式碼是由工具產生的。
'
'     對這個檔案所做的變更可能會造成錯誤的行為，而且如果重新產生程式碼，
'     所做的變更將會遺失。 
' </自動產生的>
'------------------------------------------------------------------------------

Option Strict On
Option Explicit On


Partial Public Class signup

    '''<summary>
    '''Label1 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents Label1 As Global.System.Web.UI.WebControls.Label

    '''<summary>
    '''TextBox1 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents TextBox1 As Global.System.Web.UI.WebControls.TextBox

    '''<summary>
    '''RequiredFieldValidator1 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents RequiredFieldValidator1 As Global.System.Web.UI.WebControls.RequiredFieldValidator

    '''<summary>
    '''Label2 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents Label2 As Global.System.Web.UI.WebControls.Label

    '''<summary>
    '''TextBox2 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents TextBox2 As Global.System.Web.UI.WebControls.TextBox

    '''<summary>
    '''RequiredFieldValidator2 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents RequiredFieldValidator2 As Global.System.Web.UI.WebControls.RequiredFieldValidator

    '''<summary>
    '''Label3 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents Label3 As Global.System.Web.UI.WebControls.Label

    '''<summary>
    '''TextBox3 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents TextBox3 As Global.System.Web.UI.WebControls.TextBox

    '''<summary>
    '''RequiredFieldValidator3 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents RequiredFieldValidator3 As Global.System.Web.UI.WebControls.RequiredFieldValidator

    '''<summary>
    '''Label4 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents Label4 As Global.System.Web.UI.WebControls.Label

    '''<summary>
    '''TextBox4 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents TextBox4 As Global.System.Web.UI.WebControls.TextBox

    '''<summary>
    '''RequiredFieldValidator4 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents RequiredFieldValidator4 As Global.System.Web.UI.WebControls.RequiredFieldValidator

    '''<summary>
    '''Label5 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents Label5 As Global.System.Web.UI.WebControls.Label

    '''<summary>
    '''TextBox5 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents TextBox5 As Global.System.Web.UI.WebControls.TextBox

    '''<summary>
    '''RequiredFieldValidator5 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents RequiredFieldValidator5 As Global.System.Web.UI.WebControls.RequiredFieldValidator

    '''<summary>
    '''Button1 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents Button1 As Global.System.Web.UI.WebControls.Button

    '''<summary>
    '''SqlDataSource1 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents SqlDataSource1 As Global.System.Web.UI.WebControls.SqlDataSource
End Class
