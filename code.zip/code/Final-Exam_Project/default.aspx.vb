﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Web.Configuration
Public Class _default
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If (Request.QueryString("opinionid") <> "") Then
            Detail_Panel.Visible = True
            Course_Present.Visible = False
            If (Session("acceptable") Is Nothing) Then
                Session("status") = "請先登入"
                Response.Redirect("default.aspx")
            End If
            If (Session("acceptable") = 0) Then
                Session("status") = "您的會員審核尚未通過"
                Response.Redirect("default.aspx")
            End If
        End If
    End Sub

    Protected Sub Search_btn_Click(sender As Object, e As EventArgs) Handles Search_btn.Click
        Dim Count As Integer = 0
        Dim str As String = "SELECT * FROM [course] "
        If (Period.SelectedIndex <> Period.Items.Count - 1) Then
            str &= "WHERE ([whenopen] = " + Period.SelectedValue.ToString() + ") "
            Count = Count + 1
        End If
        If (course_time.SelectedIndex <> course_time.Items.Count - 1) Then
            If (Count > 0) Then
                str &= "AND"
            Else
                str &= "WHERE "
            End If
            str &= " ([time] = " + "'" + course_time.SelectedValue.ToString() + "'" + ")"
            Count = Count + 1
        End If
        If (teacher_name.SelectedIndex <> teacher_name.Items.Count - 1) Then
            If (Count > 0) Then
                str &= "AND"
            Else
                str &= "WHERE "
            End If
            str &= " ([teacher_No] = " + teacher_name.SelectedValue.ToString() + ")"
        End If
        str &= " ORDER BY [whenopen] DESC"
        Result_SQL.SelectCommand = str
        Result_GridView.DataBind()
        ClientScript.RegisterStartupScript(GetType(String), "Javascript", "javascript:ModalCall();", True)
    End Sub

    Protected Sub opinion_btn_Click(sender As Object, e As EventArgs) Handles opinion_btn.Click
        Dim Conn As SqlConnection
        Dim Database, str As String
        Database = WebConfigurationManager.ConnectionStrings("ConnectionString").ConnectionString

        Dim lab As Label = New Label()
        lab.Text = opinion_Response.Text.Replace(System.Environment.NewLine, "<br />")
        str = "INSERT INTO [opinion] ([stu_No], [cou_No], [major], [study_year], [acceptable], [context]) VALUES (@stu_No, @cou_No, @major, @study_year, @acceptable, @context)"
        Conn = New SqlConnection(Database)
        Conn.Open()
        Dim cmd As SqlCommand = New SqlCommand(str, Conn)
        cmd.Parameters.AddWithValue("@stu_No", Session("stu_No").ToString())
        cmd.Parameters.AddWithValue("@cou_No", Request.QueryString("opinionid").ToString())
        cmd.Parameters.AddWithValue("@major", Session("major").ToString())
        cmd.Parameters.AddWithValue("@study_year", Session("study_year").ToString())
        cmd.Parameters.AddWithValue("@acceptable", 0)
        cmd.Parameters.AddWithValue("@context", lab.Text)
        Dim result As Integer = cmd.ExecuteNonQuery()
        If (result = -1) Then
            Session("status") = "發生錯誤，請重新嘗試"
        Else
            Session("status") = "新增成功，等待審核"
        End If
        cmd.Cancel()
        Conn.Close()
        Conn.Dispose()
        ScriptManager.RegisterClientScriptBlock(Me.Page, GetType(String), "StatusSecreenOut", "javascript:StatusSecreenOut();", True)
    End Sub

    Protected Sub Period_DataBound(sender As Object, e As EventArgs) Handles Period.DataBound
        Period.Items.Add(New ListItem("未選擇", ""))
        Period.SelectedIndex = Period.Items.Count - 1
    End Sub

    Protected Sub course_time_DataBound(sender As Object, e As EventArgs) Handles course_time.DataBound
        course_time.Items.Add(New ListItem("未選擇", ""))
        course_time.SelectedIndex = course_time.Items.Count - 1
    End Sub

    Protected Sub teacher_name_DataBound(sender As Object, e As EventArgs) Handles teacher_name.DataBound
        teacher_name.Items.Add(New ListItem("未選擇", ""))
        teacher_name.SelectedIndex = teacher_name.Items.Count - 1
    End Sub
End Class