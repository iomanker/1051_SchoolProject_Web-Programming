﻿Public Class _default1
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub TA_btn_Click(sender As Object, e As EventArgs) Handles TA_btn.Click
        TA_SQL.Insert()
    End Sub

    Protected Sub Period_btn_Click(sender As Object, e As EventArgs) Handles Period_btn.Click
        Period_SQL.Insert()
    End Sub
End Class