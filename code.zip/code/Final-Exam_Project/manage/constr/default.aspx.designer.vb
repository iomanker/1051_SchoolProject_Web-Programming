﻿'------------------------------------------------------------------------------
' <自動產生的>
'     這段程式碼是由工具產生的。
'
'     對這個檔案所做的變更可能會造成錯誤的行為，而且如果重新產生程式碼，
'     所做的變更將會遺失。 
' </自動產生的>
'------------------------------------------------------------------------------

Option Strict On
Option Explicit On


Partial Public Class _default1

    '''<summary>
    '''TA_GridView 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents TA_GridView As Global.System.Web.UI.WebControls.GridView

    '''<summary>
    '''Name_TextBox 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents Name_TextBox As Global.System.Web.UI.WebControls.TextBox

    '''<summary>
    '''ID_Textbox 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents ID_Textbox As Global.System.Web.UI.WebControls.TextBox

    '''<summary>
    '''TA_btn 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents TA_btn As Global.System.Web.UI.WebControls.Button

    '''<summary>
    '''TA_SQL 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents TA_SQL As Global.System.Web.UI.WebControls.SqlDataSource

    '''<summary>
    '''Period_GridView 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents Period_GridView As Global.System.Web.UI.WebControls.GridView

    '''<summary>
    '''Period_TextBox 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents Period_TextBox As Global.System.Web.UI.WebControls.TextBox

    '''<summary>
    '''Time_TextBox 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents Time_TextBox As Global.System.Web.UI.WebControls.TextBox

    '''<summary>
    '''Period_btn 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents Period_btn As Global.System.Web.UI.WebControls.Button

    '''<summary>
    '''Period_SQL 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents Period_SQL As Global.System.Web.UI.WebControls.SqlDataSource
End Class
