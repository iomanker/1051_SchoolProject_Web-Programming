﻿Public Class manage
    Inherits System.Web.UI.MasterPage

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If (Session("admin") <> 1 Or Session("admin") Is Nothing) Then
            Response.Redirect("../../default.aspx")
        End If
    End Sub

    Protected Sub logout_Click(sender As Object, e As EventArgs) Handles logout.Click
        Session.Abandon()
        Response.Redirect("~/default.aspx")
        logout.Attributes.Add("onClick", "javascript:history.clear(); return true;")
    End Sub
End Class