﻿Public Class _default4
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub AddCourse_btn_Click(sender As Object, e As EventArgs) Handles AddCourse_btn.Click
        AddCourse_SQL.Insert()
        Response.Redirect("default.aspx")
    End Sub
End Class