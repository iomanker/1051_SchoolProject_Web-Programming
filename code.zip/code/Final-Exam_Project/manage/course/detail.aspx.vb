﻿Public Class detail2
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub DetailsView1_ItemCommand(sender As Object, e As DetailsViewCommandEventArgs) Handles DetailsView1.ItemCommand
    End Sub

    Protected Sub DetailsView1_ItemDeleted(sender As Object, e As DetailsViewDeletedEventArgs) Handles DetailsView1.ItemDeleted
        Response.Redirect("default.aspx")
    End Sub
End Class