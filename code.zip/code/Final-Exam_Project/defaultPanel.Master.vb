﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Web.Configuration
Public Class defaultPanel
    Inherits System.Web.UI.MasterPage

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If (Session("stu_ID") IsNot Nothing) Then
            User_textbox.Visible = False
            pwd_textbox.Visible = False
            Send_btn.Visible = False
            Status_HyperLink.Text = "您好" + Session("stu").ToString()
            Status_HyperLink.NavigateUrl = "#"
            logout.Visible = True
        Else
            User_textbox.Visible = True
            pwd_textbox.Visible = True
            Send_btn.Visible = True
            logout.Visible = False
            Status_HyperLink.Text = "還未註冊?"
            Status_HyperLink.NavigateUrl = "~/signup.aspx"
        End If

        If (Session("admin") = 1) Then
            Label1.Visible = True
        Else
            Label1.Visible = False
        End If
    End Sub

    Protected Sub Send_btn_Click(sender As Object, e As EventArgs) Handles Send_btn.Click
        Dim Conn As SqlConnection
        Dim Database, str As String
        Dim dr As SqlDataReader
        Database = WebConfigurationManager.ConnectionStrings("ConnectionString").ConnectionString
        str = "SELECT No, stu_ID, pwd, major, study_year, acceptable, admin, stu FROM member WHERE stu_ID = @User AND pwd = @pwd"
        Conn = New SqlConnection(Database)
        Conn.Open()
        Dim cmd As SqlCommand = New SqlCommand(str, Conn)
        User_textbox.Text = User_textbox.Text.ToUpper()
        cmd.Parameters.AddWithValue("@User", User_textbox.Text)
        cmd.Parameters.AddWithValue("@pwd", pwd_textbox.Text)
        dr = cmd.ExecuteReader()
        If (Not dr.Read()) Then
            Session("status") = "帳號或密碼有誤"
            ScriptManager.RegisterClientScriptBlock(Me.Page, GetType(String), "StatusSecreenOut", "javascript:StatusSecreenOut();", True)
        Else
            Session("acceptable") = dr("acceptable")
            Session("major") = dr("major")
            Session("study_year") = dr("study_year")
            Session("stu_ID") = dr("stu_ID")
            Session("admin") = dr("admin")
            Session("stu") = dr("stu")
            Session("stu_No") = dr("No")
            Session("status") = "您好，" + dr("stu")
            Response.Redirect("default.aspx")
        End If
        dr.Close()
        cmd.Cancel()
        Conn.Close()
        Conn.Dispose()
    End Sub

    Protected Sub logout_Click(sender As Object, e As EventArgs) Handles logout.Click
        Session.Abandon()
        Session("status") = "成功登出"
        Response.Redirect("~/default.aspx")
        logout.Attributes.Add("onClick", "javascript:history.clear(); return true;")
    End Sub
End Class