﻿'------------------------------------------------------------------------------
' <自動產生的>
'     這段程式碼是由工具產生的。
'
'     對這個檔案所做的變更可能會造成錯誤的行為，而且如果重新產生程式碼，
'     所做的變更將會遺失。 
' </自動產生的>
'------------------------------------------------------------------------------

Option Strict On
Option Explicit On


Partial Public Class _default

    '''<summary>
    '''Period 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents Period As Global.System.Web.UI.WebControls.DropDownList

    '''<summary>
    '''course_time 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents course_time As Global.System.Web.UI.WebControls.DropDownList

    '''<summary>
    '''teacher_name 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents teacher_name As Global.System.Web.UI.WebControls.DropDownList

    '''<summary>
    '''Search_btn 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents Search_btn As Global.System.Web.UI.WebControls.Button

    '''<summary>
    '''Period_SQL 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents Period_SQL As Global.System.Web.UI.WebControls.SqlDataSource

    '''<summary>
    '''course_time_SQL 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents course_time_SQL As Global.System.Web.UI.WebControls.SqlDataSource

    '''<summary>
    '''teacher_name_SQL 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents teacher_name_SQL As Global.System.Web.UI.WebControls.SqlDataSource

    '''<summary>
    '''Result_GridView 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents Result_GridView As Global.System.Web.UI.WebControls.GridView

    '''<summary>
    '''Result_SQL 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents Result_SQL As Global.System.Web.UI.WebControls.SqlDataSource

    '''<summary>
    '''Course_Present 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents Course_Present As Global.System.Web.UI.WebControls.Repeater

    '''<summary>
    '''Course_Present_SQL 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents Course_Present_SQL As Global.System.Web.UI.WebControls.SqlDataSource

    '''<summary>
    '''Detail_Panel 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents Detail_Panel As Global.System.Web.UI.WebControls.Panel

    '''<summary>
    '''Course_Detail_Present 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents Course_Detail_Present As Global.System.Web.UI.WebControls.Repeater

    '''<summary>
    '''Opinion_Detail 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents Opinion_Detail As Global.System.Web.UI.WebControls.Repeater

    '''<summary>
    '''opinion_Response 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents opinion_Response As Global.System.Web.UI.WebControls.TextBox

    '''<summary>
    '''opinion_Valid 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents opinion_Valid As Global.System.Web.UI.WebControls.RequiredFieldValidator

    '''<summary>
    '''opinion_btn 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents opinion_btn As Global.System.Web.UI.WebControls.Button

    '''<summary>
    '''Course_Detail_SQL 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents Course_Detail_SQL As Global.System.Web.UI.WebControls.SqlDataSource

    '''<summary>
    '''Opinion_Detail_SQL 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents Opinion_Detail_SQL As Global.System.Web.UI.WebControls.SqlDataSource
End Class
